/**
 * Hotel Arunika Senja ERP - Role-Based Dynamic Sidebar Navigation
 * Premium Boutique Hotel & Enterprise ERP Aesthetics:
 * - Deep navy gradient: #0B2342
 * - Champagne gold brand crest & active accents: #D8AD43
 * - Active state with left gold indicator and soft interior glow
 * - Permitted modules dynamically rendered with clean typography
 */

import React from 'react';
import {
  LayoutDashboard,
  BedDouble,
  Calendar,
  TrendingUp,
  ShoppingBag,
  Warehouse,
  FileText,
  BookOpen,
  BarChart3,
  History,
  Sliders,
  LogOut,
  Database,
  Sparkles,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { canAccessPage } from '../../config/rolePermissions';

export type NavItemKey =
  | 'apps'
  | 'dashboard'
  | 'master-data'
  | 'front-desk'
  | 'bookings'
  | 'sales-crm'
  | 'purchase'
  | 'inventory'
  | 'invoicing'
  | 'accounting'
  | 'reports'
  | 'audit-log'
  | 'settings';

interface SidebarProps {
  activePage: NavItemKey;
  onNavigate: (page: NavItemKey) => void;
  onSignOut: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activePage, onNavigate, onSignOut }) => {
  const { currentUser } = useERP();

  const allNavItems: { key: NavItemKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { key: 'master-data', label: 'Master Data', icon: Database },
    { key: 'front-desk', label: 'Front Desk', icon: BedDouble },
    { key: 'bookings', label: 'Bookings', icon: Calendar },
    { key: 'sales-crm', label: 'Sales & CRM', icon: TrendingUp },
    { key: 'purchase', label: 'Purchase', icon: ShoppingBag },
    { key: 'inventory', label: 'Inventory', icon: Warehouse },
    { key: 'invoicing', label: 'Invoicing', icon: FileText },
    { key: 'accounting', label: 'Accounting', icon: BookOpen },
    { key: 'reports', label: 'Reports', icon: BarChart3 },
    { key: 'audit-log', label: 'Audit Log', icon: History },
    { key: 'settings', label: 'Settings', icon: Sliders },
  ];

  // Filter permitted nav items according to active role
  const permittedItems = allNavItems.filter(item => canAccessPage(currentUser.role, item.key));

  return (
    <aside className="w-60 bg-gradient-to-b from-[#0B2342] via-[#091D36] to-[#061527] text-[#CBD5E1] flex flex-col shrink-0 h-screen sticky top-0 z-30 select-none border-r border-[#1B3556] shadow-xl">
      {/* Brand Header */}
      <div className="px-5 py-4 border-b border-[#1A3455] flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#E6BE58] to-[#C2932E] flex items-center justify-center text-[#0B2342] font-extrabold text-xs shrink-0 shadow-md ring-1 ring-white/20">
            AS
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-white tracking-tight truncate font-serif-luxury">
              Arunika Senja
            </h1>
            <p className="text-[10px] text-[#D8AD43] font-medium tracking-wider uppercase truncate">
              Boutique Hotel ERP
            </p>
          </div>
        </div>
      </div>

      {/* Active Role Indicator Card */}
      <div className="px-3 pt-3 pb-2">
        <div className="p-2.5 rounded-xl bg-[#142D4B]/90 border border-[#21436E]/60 text-xs shadow-inner">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-[#D8AD43]/20 text-[#D8AD43] font-bold text-[10px] flex items-center justify-center border border-[#D8AD43]/50 shrink-0 shadow-2xs">
              {currentUser.avatar || currentUser.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-white truncate text-xs">{currentUser.name}</div>
              <div className="text-[10px] text-[#D8AD43] truncate font-medium">{currentUser.roleLabel}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Applications Hub Top Button */}
      <div className="px-3 py-1">
        <button
          onClick={() => onNavigate('apps')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activePage === 'apps'
              ? 'bg-[#173B65] text-white shadow-xs border-l-3 border-[#D8AD43]'
              : 'text-[#CBD5E1] hover:text-white hover:bg-[#142E4D]'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#D8AD43]" />
          <span>Applications Hub</span>
        </button>
      </div>

      {/* Permitted Menu Navigation List */}
      <div className="px-3 py-2">
        <div className="text-[10px] font-bold tracking-widest text-[#8CA3BF] uppercase px-3 py-1.5 flex items-center justify-between">
          <span>Permitted Modules</span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#16365C] text-[#D8AD43]">
            {permittedItems.length}
          </span>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 space-y-1 pb-4">
        {permittedItems.map(item => {
          const Icon = item.icon;
          const isActive = activePage === item.key;

          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#173B65] text-white font-semibold shadow-xs border-l-3 border-[#D8AD43] pl-2.5'
                  : 'text-[#B2C5DD] hover:text-white hover:bg-[#132A46]'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-[#D8AD43]' : 'text-[#8EA8C7]'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Sign Out Button */}
      <div className="p-3 border-t border-[#1A3455]">
        <button
          onClick={onSignOut}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-[#9BB1CC] hover:text-rose-300 hover:bg-rose-950/30 transition-colors cursor-pointer font-medium"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>Sign out / Exit</span>
        </button>
      </div>
    </aside>
  );
};
