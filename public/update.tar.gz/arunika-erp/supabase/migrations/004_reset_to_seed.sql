-- Migration 004: Reset to seed function
-- Date: 2026-10-28
-- Purpose: Provide a function to reset all inventory data to baseline seed state
CREATE OR REPLACE FUNCTION reset_to_seed (p_actor_id uuid DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- =============================================================================
  -- TRUNCATE ALL TABLES (except profiles and auth.users)
  -- =============================================================================

  TRUNCATE TABLE delivery_lines RESTART IDENTITY CASCADE;
  TRUNCATE TABLE deliveries RESTART IDENTITY CASCADE;
  TRUNCATE TABLE receipt_lines RESTART IDENTITY CASCADE;
  TRUNCATE TABLE receipts RESTART IDENTITY CASCADE;
  TRUNCATE TABLE purchase_order_lines RESTART IDENTITY CASCADE;
  TRUNCATE TABLE purchase_orders RESTART IDENTITY CASCADE;
  TRUNCATE TABLE stock_moves RESTART IDENTITY CASCADE;
  TRUNCATE TABLE stock_quants RESTART IDENTITY CASCADE;
  TRUNCATE TABLE vendor_pricelist RESTART IDENTITY CASCADE;
  TRUNCATE TABLE products RESTART IDENTITY CASCADE;
  TRUNCATE TABLE vendors RESTART IDENTITY CASCADE;
  TRUNCATE TABLE locations RESTART IDENTITY CASCADE;
  TRUNCATE TABLE doc_sequences RESTART IDENTITY CASCADE;
  TRUNCATE TABLE audit_log RESTART IDENTITY CASCADE;

  -- =============================================================================
  -- 1. LOCATIONS (warehouses_locations)
  -- =============================================================================

  INSERT INTO locations (id, code, name, location_type, is_active) VALUES
  ('10000000-0000-0000-0000-000000000001', 'WH-JKT', 'Gudang pusat', 'internal', TRUE),
  ('10000000-0000-0000-0000-000000000002', 'MB-JKT', 'Pantry minibar', 'internal', TRUE);

  -- =============================================================================
  -- 2. VENDORS (contacts_vendors)
  -- =============================================================================

  INSERT INTO vendors (id, code, name, city, payment_terms, is_active) VALUES
  ('20000000-0000-0000-0000-000000000001', 'V01', 'PT Tirta Distribusi', 'Jakarta', 'Net 14', TRUE),
  ('20000000-0000-0000-0000-000000000002', 'V02', 'PT Camilan Nusantara', 'Tangerang', 'Net 14', TRUE),
  ('20000000-0000-0000-0000-000000000003', 'V03', 'PT Prima Amenitas', 'Bekasi', 'Net 30', TRUE),
  ('20000000-0000-0000-0000-000000000004', 'V04', 'PT Tekstil Hotelindo', 'Bandung', 'Net 30', TRUE);

  -- =============================================================================
  -- 3. PRODUCTS (products with default_vendor_id, sales_price, size, color)
  -- =============================================================================

  INSERT INTO products (id, code, name, unit, cost_price, sales_price, size, color, default_vendor_id, is_active) VALUES
  -- V01 products (Tirta Distribusi)
  ('30000000-0000-0000-0000-000000000001', 'MB-WTR-330', 'Air mineral 330 ml', 'botol', 6000, 18000, '330 ml', 'Bening', '20000000-0000-0000-0000-000000000001', TRUE),
  ('30000000-0000-0000-0000-000000000002', 'MB-SODA-CAN', 'Soda kaleng', 'kaleng', 10000, 25000, '330 ml', 'Perak', '20000000-0000-0000-0000-000000000001', TRUE),
  ('30000000-0000-0000-0000-000000000003', 'MB-JUICE-250', 'Jus buah kotak', 'kotak', 12000, 28000, '250 ml', 'Jingga', '20000000-0000-0000-0000-000000000001', TRUE),

  -- V02 products (Camilan Nusantara)
  ('30000000-0000-0000-0000-000000000004', 'MB-CHIP-SALT', 'Keripik original', 'bungkus', 8000, 22000, '60 g', 'Krem', '20000000-0000-0000-0000-000000000002', TRUE),
  ('30000000-0000-0000-0000-000000000005', 'MB-CHIP-SPCY', 'Keripik pedas', 'bungkus', 9000, 24000, '60 g', 'Merah', '20000000-0000-0000-0000-000000000002', TRUE),
  ('30000000-0000-0000-0000-000000000006', 'MB-CHOC-DARK', 'Cokelat hitam', 'batang', 14000, 30000, '45 g', 'Cokelat tua', '20000000-0000-0000-0000-000000000002', TRUE),
  ('30000000-0000-0000-0000-000000000007', 'MB-CHOC-MILK', 'Cokelat susu', 'batang', 13000, 30000, '45 g', 'Cokelat muda', '20000000-0000-0000-0000-000000000002', TRUE),

  -- V03 products (Prima Amenitas)
  ('30000000-0000-0000-0000-000000000008', 'AM-SOAP-LAV', 'Sabun lavender', 'batang', 7000, 18000, '30 g', 'Ungu', '20000000-0000-0000-0000-000000000003', TRUE),
  ('30000000-0000-0000-0000-000000000009', 'AM-SOAP-CIT', 'Sabun citrus', 'batang', 7000, 18000, '30 g', 'Kuning', '20000000-0000-0000-0000-000000000003', TRUE),
  ('30000000-0000-0000-0000-000000000010', 'AM-SHMP-50', 'Sampo tamu', 'botol', 12000, 25000, '50 ml', 'Putih', '20000000-0000-0000-0000-000000000003', TRUE),
  ('30000000-0000-0000-0000-000000000011', 'AM-BRUSH', 'Sikat gigi tamu', 'set', 5000, 16000, 'Standar', 'Putih', '20000000-0000-0000-0000-000000000003', TRUE),
  ('30000000-0000-0000-0000-000000000012', 'AM-SLIPPER', 'Sandal hotel', 'pasang', 14000, 35000, 'Universal', 'Abu', '20000000-0000-0000-0000-000000000003', TRUE),

  -- V04 products (Tekstil Hotelindo)
  ('30000000-0000-0000-0000-000000000013', 'HK-TOWEL-W', 'Handuk mandi', 'pcs', 43000, 85000, '70×140 cm', 'Putih', '20000000-0000-0000-0000-000000000004', TRUE),
  ('30000000-0000-0000-0000-000000000014', 'HK-TOWEL-G', 'Handuk mandi', 'pcs', 45000, 85000, '70×140 cm', 'Abu', '20000000-0000-0000-0000-000000000004', TRUE),
  ('30000000-0000-0000-0000-000000000015', 'HK-LINEN-SET', 'Set linen kamar', 'set', 120000, 210000, 'Queen', 'Putih', '20000000-0000-0000-0000-000000000004', TRUE);

  -- =============================================================================
  -- 4. VENDOR PRICELIST (vendor_pricelist)
  -- =============================================================================

  INSERT INTO vendor_pricelist (vendor_id, product_id, vendor_price_idr, min_qty) VALUES
  -- V01 - Tirta Distribusi
  ('20000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001', 6000, 1),   -- MB-WTR-330
  ('20000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000002', 10000, 1),  -- MB-SODA-CAN
  ('20000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000003', 12000, 1),  -- MB-JUICE-250

  -- V02 - Camilan Nusantara
  ('20000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000004', 8000, 1),   -- MB-CHIP-SALT
  ('20000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000005', 9000, 1),   -- MB-CHIP-SPCY
  ('20000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000006', 14000, 1),  -- MB-CHOC-DARK
  ('20000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000007', 13000, 1),  -- MB-CHOC-MILK

  -- V03 - Prima Amenitas
  ('20000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000008', 7000, 1),   -- AM-SOAP-LAV
  ('20000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000009', 7000, 1),   -- AM-SOAP-CIT
  ('20000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000010', 12000, 1),  -- AM-SHMP-50
  ('20000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000011', 5000, 1),   -- AM-BRUSH
  ('20000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000012', 14000, 1),  -- AM-SLIPPER

  -- V04 - Tekstil Hotelindo
  ('20000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000013', 43000, 1),  -- HK-TOWEL-W
  ('20000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000014', 45000, 1),  -- HK-TOWEL-G
  ('20000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000015', 120000, 1); -- HK-LINEN-SET

  -- =============================================================================
  -- 5. STOCK QUANTS (opening_stock)
  -- Control baseline - persediaan: Total stok 1.086 unit, total nilai Rp14.102.000
  -- SO00007 sudah me-reserve 4 air dan 2 soda di MB-JKT
  -- =============================================================================

  INSERT INTO stock_quants (product_id, location_id, on_hand, reserved) VALUES
  -- MB-WTR-330: WH 120, MB 30 (reserved 4)
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 120, 0),
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', 30, 4),

  -- MB-SODA-CAN: WH 70, MB 20 (reserved 2)
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', 70, 0),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', 20, 2),

  -- MB-JUICE-250: WH 60, MB 20
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000001', 60, 0),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000002', 20, 0),

  -- MB-CHIP-SALT: WH 80, MB 15
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000001', 80, 0),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000002', 15, 0),

  -- MB-CHIP-SPCY: WH 70, MB 15
  ('30000000-0000-0000-0000-000000000005', '10000000-0000-0000-0000-000000000001', 70, 0),
  ('30000000-0000-0000-0000-000000000005', '10000000-0000-0000-0000-000000000002', 15, 0),

  -- MB-CHOC-DARK: WH 45, MB 10
  ('30000000-0000-0000-0000-000000000006', '10000000-0000-0000-0000-000000000001', 45, 0),
  ('30000000-0000-0000-0000-000000000006', '10000000-0000-0000-0000-000000000002', 10, 0),

  -- MB-CHOC-MILK: WH 50, MB 10
  ('30000000-0000-0000-0000-000000000007', '10000000-0000-0000-0000-000000000001', 50, 0),
  ('30000000-0000-0000-0000-000000000007', '10000000-0000-0000-0000-000000000002', 10, 0),

  -- AM-SOAP-LAV: WH 80, MB 15
  ('30000000-0000-0000-0000-000000000008', '10000000-0000-0000-0000-000000000001', 80, 0),
  ('30000000-0000-0000-0000-000000000008', '10000000-0000-0000-0000-000000000002', 15, 0),

  -- AM-SOAP-CIT: WH 70, MB 15
  ('30000000-0000-0000-0000-000000000009', '10000000-0000-0000-0000-000000000001', 70, 0),
  ('30000000-0000-0000-0000-000000000009', '10000000-0000-0000-0000-000000000002', 15, 0),

  -- AM-SHMP-50: WH 55, MB 15
  ('30000000-0000-0000-0000-000000000010', '10000000-0000-0000-0000-000000000001', 55, 0),
  ('30000000-0000-0000-0000-000000000010', '10000000-0000-0000-0000-000000000002', 15, 0),

  -- AM-BRUSH: WH 70, MB 10
  ('30000000-0000-0000-0000-000000000011', '10000000-0000-0000-0000-000000000001', 70, 0),
  ('30000000-0000-0000-0000-000000000011', '10000000-0000-0000-0000-000000000002', 10, 0),

  -- AM-SLIPPER: WH 50, MB 10
  ('30000000-0000-0000-0000-000000000012', '10000000-0000-0000-0000-000000000001', 50, 0),
  ('30000000-0000-0000-0000-000000000012', '10000000-0000-0000-0000-000000000002', 10, 0),

  -- HK-TOWEL-W: WH 30, MB 4
  ('30000000-0000-0000-0000-000000000013', '10000000-0000-0000-0000-000000000001', 30, 0),
  ('30000000-0000-0000-0000-000000000013', '10000000-0000-0000-0000-000000000002', 4, 0),

  -- HK-TOWEL-G: WH 25, MB 4
  ('30000000-0000-0000-0000-000000000014', '10000000-0000-0000-0000-000000000001', 25, 0),
  ('30000000-0000-0000-0000-000000000014', '10000000-0000-0000-0000-000000000002', 4, 0),

  -- HK-LINEN-SET: WH 16, MB 2
  ('30000000-0000-0000-0000-000000000015', '10000000-0000-0000-0000-000000000001', 16, 0),
  ('30000000-0000-0000-0000-000000000015', '10000000-0000-0000-0000-000000000002', 2, 0);

  -- =============================================================================
  -- 6. STOCK MOVES (opening stock movements)
  -- One move per stock_quants entry: generated from SELECT
  -- =============================================================================

  INSERT INTO stock_moves (product_id, from_location_id, to_location_id, qty, reference_doc, ref_type)
  SELECT product_id, NULL, location_id, on_hand, 'OPENING', 'opening' FROM stock_quants;

  -- =============================================================================
  -- 7. DOC SEQUENCES
  -- PO terakhir adalah 7, supaya PO berikutnya jadi PO00008
  -- DO terakhir adalah 0, supaya DO berikutnya jadi DO00001
  -- RC terakhir adalah 0, supaya RC berikutnya jadi RC00001
  -- =============================================================================

  INSERT INTO doc_sequences (doc_type, prefix, last_number) VALUES
  ('PO', 'PO', 7),
  ('DO', 'DO', 0),
  ('RC', 'RC', 0);

  -- =============================================================================
  -- 8. PO00007 (existing_documents)
  -- Purchase Order V02 Confirmed: 10×MB-CHIP-SALT @Rp8.000
  -- Status: Confirmed, belum diterima, AP=0
  -- =============================================================================

  -- Purchase Order PO00007
  INSERT INTO purchase_orders (id, po_no, vendor_id, order_date, status, subtotal_amount, tax_amount, total_amount, created_by) VALUES
  ('60000000-0000-0000-0000-000000000001',
   'PO00007',
   '20000000-0000-0000-0000-000000000002',  -- vendor_id (V02)
   '2026-10-20',  -- reasonable date before current date
   'confirmed',
   80000,  -- subtotal: 10 × 8000
   8800,   -- tax: 80000 × 11% = 8800
   88800,  -- total (bruto): 80000 + 8800
   NULL);  -- created_by = NULL

  -- Purchase Order Lines for PO00007
  INSERT INTO purchase_order_lines (po_id, product_id, qty, unit_price, subtotal) VALUES
  ('60000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000004', 10, 8000, 80000);

  -- =============================================================================
  -- AUDIT LOG: Record reset action
  -- =============================================================================

  INSERT INTO audit_log (actor_id, action, doc_no, new_value)
  VALUES (
    p_actor_id,
    'RESET_TO_SEED',
    'SYSTEM',
    jsonb_build_object('note', 'reset to seed')
  );

END;
$$;


-- Add comment to function
COMMENT ON FUNCTION reset_to_seed (uuid) IS 'Reset all inventory data to baseline seed state. Truncates all tables except profiles and auth.users, then re-inserts seed data.';


REVOKE ALL ON FUNCTION reset_to_seed (uuid)
FROM
  PUBLIC,
  anon,
  authenticated;


GRANT
EXECUTE ON FUNCTION reset_to_seed (uuid) TO service_role;